package sy.salati

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager

class SalatiApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_HIGH)
        )
    }
    companion object { const val CHANNEL_ID = "prayer_times" }
}
