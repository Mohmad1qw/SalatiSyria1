package sy.salati.ui.home

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import sy.salati.R
import sy.salati.domain.Prayer
import sy.salati.domain.PrayerEntry
import sy.salati.ui.components.GlassCard
import sy.salati.ui.components.drawWave
import sy.salati.ui.theme.SyColors
import java.time.Duration
import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale
import kotlin.math.PI

private fun iconFor(p: Prayer): ImageVector = when (p) {
    Prayer.FAJR -> Icons.Rounded.WbTwilight
    Prayer.SUNRISE -> Icons.Rounded.WbSunny
    Prayer.DHUHR -> Icons.Rounded.LightMode
    Prayer.ASR -> Icons.Rounded.WbCloudy
    Prayer.MAGHRIB -> Icons.Rounded.NightsStay
    Prayer.ISHA -> Icons.Rounded.Bedtime
}

@Composable
fun HomeScreen(vm: HomeViewModel = viewModel()) {
    val s by vm.ui.collectAsStateWithLifecycle()
    val h = s ?: return
    val locale = LocalConfiguration.current.locales[0] ?: Locale.getDefault()
    val timeFmt = remember(locale) { DateTimeFormatter.ofPattern("hh:mm a", locale) }

    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(20.dp, 12.dp, 20.dp, 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Header(h, locale, timeFmt) }
        item { NextPrayerCard(h, timeFmt) }
        items(h.today, key = { it.prayer }) { e ->
            PrayerRow(e, isNext = e.prayer == h.state.next.prayer, timeFmt)
        }
    }
}

@Composable
private fun Header(h: HomeState, locale: Locale, timeFmt: DateTimeFormatter) {
    val hijri = remember(h.now.toLocalDate(), locale) {
        DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG).withLocale(locale).format(HijrahDate.from(h.now.toLocalDate()))
    }
    val greg = remember(h.now.toLocalDate(), locale) {
        DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL).withLocale(locale).format(h.now.toLocalDate())
    }
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.LocationOn, null, tint = SyColors.FlagRed, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(4.dp))
            Text("${stringResource(h.city.nameRes)}، ${stringResource(R.string.country)}", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        }
        Text(timeFmt.format(h.now), fontSize = 40.sp, fontWeight = FontWeight.Light)
        Text(hijri, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
        Text(greg, fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f))
    }
}

@Composable
private fun NextPrayerCard(h: HomeState, timeFmt: DateTimeFormatter) {
    val st = h.state
    val primary = MaterialTheme.colorScheme.primary
    val phase by rememberInfiniteTransition(label = "ring").animateFloat(
        0f, (2 * PI).toFloat(), infiniteRepeatable(tween(6000, easing = LinearEasing)), label = "p"
    )
    GlassCard(Modifier.fillMaxWidth(), corner = 36.dp, highlight = true) {
        Column(Modifier.padding(24.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(stringResource(R.string.next_prayer), fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f))
            Spacer(Modifier.height(14.dp))
            Box(Modifier.size(250.dp), contentAlignment = Alignment.Center) {
                // liquid fill: water level = time remaining until the next prayer
                Canvas(Modifier.fillMaxSize().padding(10.dp).clip(CircleShape)) {
                    val level = size.height * (st.progress)
                    drawWave(level, 9f, 1.4f, phase, SyColors.Water.copy(alpha = 0.35f))
                    drawWave(level + 8f, 7f, 1.0f, -phase + 1f, SyColors.Emerald.copy(alpha = 0.30f))
                }
                // progress ring
                Canvas(Modifier.fillMaxSize()) {
                    val sw = 7.dp.toPx()
                    drawArc(Color.White.copy(alpha = 0.18f), 0f, 360f, false, Offset(sw / 2, sw / 2), Size(size.width - sw, size.height - sw), style = Stroke(sw))
                    drawArc(
                        Brush.sweepGradient(listOf(SyColors.Water, primary, SyColors.Water)),
                        -90f, 360f * st.progress, false, Offset(sw / 2, sw / 2), Size(size.width - sw, size.height - sw),
                        style = Stroke(sw, cap = StrokeCap.Round)
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(stringResource(st.next.prayer.nameRes), fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    Text(timeFmt.format(st.next.time), fontSize = 22.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(formatRemaining(st.remaining), fontSize = 26.sp, fontWeight = FontWeight.Light, color = primary)
                    Text(stringResource(R.string.remaining), fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                }
            }
        }
    }
}

private fun formatRemaining(d: Duration): String {
    val s = d.seconds.coerceAtLeast(0)
    return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
}

@Composable
private fun PrayerRow(e: PrayerEntry, isNext: Boolean, timeFmt: DateTimeFormatter) {
    GlassCard(Modifier.fillMaxWidth(), corner = 22.dp, highlight = isNext) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(iconFor(e.prayer), null, tint = if (isNext) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.75f))
            Spacer(Modifier.width(14.dp))
            Text(stringResource(e.prayer.nameRes), Modifier.weight(1f), fontSize = 18.sp, fontWeight = if (isNext) FontWeight.Bold else FontWeight.Medium)
            Text(timeFmt.format(e.time), fontSize = 18.sp, fontWeight = if (isNext) FontWeight.Bold else FontWeight.Normal)
        }
    }
}
