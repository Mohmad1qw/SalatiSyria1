package sy.salati

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import sy.salati.notify.PrayerScheduler
import sy.salati.ui.components.WaterBackground
import sy.salati.ui.home.HomeScreen
import sy.salati.ui.theme.SalatiTheme

private enum class Tab(val label: Int, val icon: ImageVector) {
    HOME(R.string.nav_home, Icons.Rounded.Home),
    TIMES(R.string.nav_times, Icons.Rounded.Schedule),
    QIBLA(R.string.nav_qibla, Icons.Rounded.Explore),
    DHIKR(R.string.nav_dhikr, Icons.Rounded.AutoAwesome),
    SETTINGS(R.string.nav_settings, Icons.Rounded.Settings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycleScope.launch { PrayerScheduler(applicationContext).scheduleNext() }
        setContent {
            SalatiTheme {
                val askNotif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= 33) askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                var tab by remember { mutableStateOf(Tab.HOME) }
                WaterBackground {
                    Scaffold(
                        containerColor = Color.Transparent,
                        bottomBar = {
                            NavigationBar(containerColor = Color.White.copy(alpha = 0.10f)) {
                                Tab.entries.forEach { t ->
                                    NavigationBarItem(
                                        selected = tab == t, onClick = { tab = t },
                                        icon = { Icon(t.icon, null) },
                                        label = { Text(stringResource(t.label)) }
                                    )
                                }
                            }
                        }
                    ) { pad ->
                        Box(Modifier.padding(pad).fillMaxSize()) {
                            if (tab == Tab.HOME) HomeScreen()
                            else Box(Modifier.fillMaxSize(), Alignment.Center) { Text(stringResource(R.string.coming_soon)) }
                        }
                    }
                }
            }
        }
    }
}
