package sy.salati.domain

import java.time.Duration
import java.time.ZonedDateTime

data class PrayerState(
    val previous: PrayerEntry,
    val next: PrayerEntry,
    val remaining: Duration,
    /** 0f..1f progress between previous and next prayer */
    val progress: Float
)

fun List<PrayerEntry>.stateAt(now: ZonedDateTime): PrayerState {
    val next = first { it.time.isAfter(now) }
    val prev = last { !it.time.isAfter(now) }
    val total = Duration.between(prev.time, next.time).toMillis().coerceAtLeast(1)
    val elapsed = Duration.between(prev.time, now).toMillis()
    return PrayerState(prev, next, Duration.between(now, next.time), (elapsed.toFloat() / total).coerceIn(0f, 1f))
}

/** Next prayer that should trigger a notification (Sunrise is skipped). */
fun List<PrayerEntry>.nextNotifiable(now: ZonedDateTime): PrayerEntry? =
    firstOrNull { it.prayer.notifiable && it.time.isAfter(now) }
