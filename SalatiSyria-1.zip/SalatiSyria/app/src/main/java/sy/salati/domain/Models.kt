package sy.salati.domain

import androidx.annotation.StringRes
import sy.salati.R
import java.time.ZonedDateTime

enum class Prayer(@StringRes val nameRes: Int, val notifiable: Boolean) {
    FAJR(R.string.prayer_fajr, true),
    SUNRISE(R.string.prayer_sunrise, false),
    DHUHR(R.string.prayer_dhuhr, true),
    ASR(R.string.prayer_asr, true),
    MAGHRIB(R.string.prayer_maghrib, true),
    ISHA(R.string.prayer_isha, true)
}

enum class Madhhab(val asrFactor: Double) { SHAFII(1.0), HANAFI(2.0) }

/** Fajr/Isha twilight angles in degrees. If [ishaMinutesAfterMaghrib] is set, it overrides the Isha angle. */
enum class CalcMethod(val fajrAngle: Double, val ishaAngle: Double, val ishaMinutesAfterMaghrib: Int? = null) {
    EGYPT(19.5, 17.5),
    MWL(18.0, 17.0),
    KARACHI(18.0, 18.0),
    UMM_AL_QURA(18.5, 0.0, 90),
    ISNA(15.0, 15.0)
}

data class City(val id: String, @StringRes val nameRes: Int, val lat: Double, val lng: Double)

data class PrayerEntry(val prayer: Prayer, val time: ZonedDateTime)

object SyrianCities {
    val all = listOf(
        City("damascus", R.string.city_damascus, 33.5138, 36.2765),
        City("rural_damascus", R.string.city_rural_damascus, 33.5716, 36.4017),
        City("aleppo", R.string.city_aleppo, 36.2021, 37.1343),
        City("homs", R.string.city_homs, 34.7324, 36.7137),
        City("hama", R.string.city_hama, 35.1318, 36.7578),
        City("latakia", R.string.city_latakia, 35.5317, 35.7900),
        City("tartus", R.string.city_tartus, 34.8890, 35.8866),
        City("idlib", R.string.city_idlib, 35.9306, 36.6339),
        City("daraa", R.string.city_daraa, 32.6189, 36.1021),
        City("suwayda", R.string.city_suwayda, 32.7090, 36.5695),
        City("quneitra", R.string.city_quneitra, 33.1260, 35.8240),
        City("deir_ez_zor", R.string.city_deir_ez_zor, 35.3359, 40.1408),
        City("raqqa", R.string.city_raqqa, 35.9528, 39.0079),
        City("hasakah", R.string.city_hasakah, 36.5024, 40.7477)
    )
    fun byId(id: String) = all.firstOrNull { it.id == id } ?: all.first()
    /** Nearest governorate centre to a GPS fix (used by auto-detect, next stage). */
    fun nearest(lat: Double, lng: Double) = all.minBy { (it.lat - lat) * (it.lat - lat) + (it.lng - lng) * (it.lng - lng) }
}
