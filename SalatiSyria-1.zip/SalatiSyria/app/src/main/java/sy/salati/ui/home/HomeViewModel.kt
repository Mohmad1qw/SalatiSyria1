package sy.salati.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import sy.salati.data.SettingsRepository
import sy.salati.domain.*
import java.time.ZonedDateTime

data class HomeState(
    val city: City,
    val now: ZonedDateTime,
    val today: List<PrayerEntry>,
    val state: PrayerState
)

class HomeViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SettingsRepository(app)

    private val ticker = flow { while (true) { emit(ZonedDateTime.now(PrayerCalculator.SYRIA)); delay(1000) } }

    val ui: StateFlow<HomeState?> = combine(repo.settings, ticker) { s, now ->
        val city = SyrianCities.byId(s.cityId)
        val timeline = PrayerCalculator.timeline(now, city, s.method, s.madhhab)
        val today = timeline.filter { it.time.toLocalDate() == now.toLocalDate() }
        HomeState(city, now, today, timeline.stateAt(now))
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
}
