package sy.salati.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Liquid-glass surface: translucent diagonal fill + bright top-left rim that fades out (light refraction).
 * Real backdrop blur needs RenderEffect on a layer behind the card; this stays cheap and works on API 26+.
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    corner: Dp = 28.dp,
    highlight: Boolean = false,
    content: @Composable () -> Unit
) {
    val dark = isSystemInDarkTheme()
    val shape = RoundedCornerShape(corner)
    val tint = if (dark) Color.White else Color.White
    val fill = Brush.linearGradient(
        listOf(tint.copy(alpha = if (dark) 0.14f else 0.55f), tint.copy(alpha = if (dark) 0.05f else 0.25f))
    )
    val rim = Brush.linearGradient(
        listOf(Color.White.copy(alpha = if (highlight) 0.9f else 0.55f), Color.White.copy(alpha = 0.06f), Color.White.copy(alpha = 0.25f))
    )
    Box(modifier.clip(shape).background(fill).border(if (highlight) 1.5.dp else 1.dp, rim, shape).padding(0.dp)) {
        content()
    }
}
