package sy.salati.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Palette drawn from Syria: olive groves, Damascene stone, deep sky/water, a restrained flag red.
object SyColors {
    val Emerald = Color(0xFF0F5C4A)
    val DeepOlive = Color(0xFF1E3B2F)
    val Night = Color(0xFF07211C)
    val Ivory = Color(0xFFF7F1E3)
    val Stone = Color(0xFFD9CDB4)
    val DeepBlue = Color(0xFF123A5E)
    val Water = Color(0xFF4FB0C6)
    val FlagRed = Color(0xFFC0392B)
    val Gold = Color(0xFFD8B26A)
}

private val Dark = darkColorScheme(
    primary = SyColors.Gold, onPrimary = SyColors.Night,
    secondary = SyColors.Water, tertiary = SyColors.FlagRed,
    background = SyColors.Night, surface = SyColors.DeepOlive,
    onBackground = SyColors.Ivory, onSurface = SyColors.Ivory
)
private val Light = lightColorScheme(
    primary = SyColors.Emerald, onPrimary = SyColors.Ivory,
    secondary = SyColors.DeepBlue, tertiary = SyColors.FlagRed,
    background = SyColors.Ivory, surface = SyColors.Stone,
    onBackground = SyColors.Night, onSurface = SyColors.Night
)

@Composable
fun SalatiTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
