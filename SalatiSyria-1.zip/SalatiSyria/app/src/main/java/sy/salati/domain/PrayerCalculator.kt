package sy.salati.domain

import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.math.*

/**
 * Offline astronomical prayer-time calculation (same family of formulas as PrayTimes.org).
 * Pure Kotlin, no network, no Android dependencies -> easy to unit-test.
 */
object PrayerCalculator {
    val SYRIA: ZoneId = ZoneId.of("Asia/Damascus")

    fun calculate(
        date: LocalDate,
        city: City,
        method: CalcMethod,
        madhhab: Madhhab,
        adjustMinutes: Map<Prayer, Int> = emptyMap(),
        zone: ZoneId = SYRIA
    ): List<PrayerEntry> {
        val start = date.atStartOfDay(zone)
        val tz = zone.rules.getOffset(start.toInstant()).totalSeconds / 3600.0
        val jd = julian(date.year, date.monthValue, date.dayOfMonth) - city.lng / (15.0 * 24.0)
        val lat = city.lat

        fun mid(t: Double) = fixHour(12.0 - sun(jd + t / 24.0).second)

        fun angleTime(angle: Double, t: Double, ccw: Boolean): Double {
            val decl = sun(jd + t / 24.0).first
            val x = (-sinD(angle) - sinD(decl) * sinD(lat)) / (cosD(decl) * cosD(lat))
            val tt = Math.toDegrees(acos(x.coerceIn(-1.0, 1.0))) / 15.0
            return mid(t) + if (ccw) -tt else tt
        }

        fun asr(factor: Double, t: Double): Double {
            val decl = sun(jd + t / 24.0).first
            val a = -Math.toDegrees(atan(1.0 / (factor + tan(Math.toRadians(abs(lat - decl))))))
            return angleTime(a, t, false)
        }

        val maghrib = angleTime(0.833, 18.0, false)
        val isha = method.ishaMinutesAfterMaghrib?.let { maghrib + it / 60.0 } ?: angleTime(method.ishaAngle, 18.0, false)

        val raw = mapOf(
            Prayer.FAJR to angleTime(method.fajrAngle, 5.0, true),
            Prayer.SUNRISE to angleTime(0.833, 6.0, true),
            Prayer.DHUHR to mid(12.0) + 1.0 / 60.0, // +1 min safety margin after zenith
            Prayer.ASR to asr(madhhab.asrFactor, 13.0),
            Prayer.MAGHRIB to maghrib,
            Prayer.ISHA to isha
        )
        val tzShift = tz - city.lng / 15.0
        return Prayer.entries.map { p ->
            val minutes = ((raw.getValue(p) + tzShift) * 60.0).roundToLong() + (adjustMinutes[p] ?: 0)
            PrayerEntry(p, start.plusMinutes(minutes))
        }
    }

    /** Yesterday + today + tomorrow, sorted: gives previous/next prayer across midnight. */
    fun timeline(now: ZonedDateTime, city: City, method: CalcMethod, madhhab: Madhhab, adj: Map<Prayer, Int> = emptyMap()): List<PrayerEntry> {
        val d = now.withZoneSameInstant(SYRIA).toLocalDate()
        return (-1L..1L).flatMap { calculate(d.plusDays(it), city, method, madhhab, adj) }.sortedBy { it.time }
    }

    private fun julian(y0: Int, m0: Int, d: Int): Double {
        var y = y0; var m = m0
        if (m <= 2) { y -= 1; m += 12 }
        val a = floor(y / 100.0); val b = 2 - a + floor(a / 4)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + d + b - 1524.5
    }

    /** returns (declination in degrees, equation of time in hours) */
    private fun sun(jd: Double): Pair<Double, Double> {
        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sinD(g) + 0.020 * sinD(2 * g))
        val e = 23.439 - 0.00000036 * d
        val ra = fixHour(Math.toDegrees(atan2(cosD(e) * sinD(l), cosD(l))) / 15.0)
        val decl = Math.toDegrees(asin(sinD(e) * sinD(l)))
        return decl to (q / 15.0 - ra)
    }

    private fun sinD(d: Double) = sin(Math.toRadians(d))
    private fun cosD(d: Double) = cos(Math.toRadians(d))
    private fun fixAngle(a: Double) = ((a % 360) + 360) % 360
    private fun fixHour(h: Double) = ((h % 24) + 24) % 24
}
