package sy.salati.notify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.flow.first
import sy.salati.data.SettingsRepository
import sy.salati.domain.*
import java.time.ZonedDateTime

/**
 * Battery-efficient strategy: only ONE alarm is ever pending (the next prayer).
 * When it fires, the receiver posts the notification and schedules the following one.
 */
class PrayerScheduler(private val context: Context) {

    suspend fun scheduleNext() {
        val s = SettingsRepository(context).settings.first()
        val now = ZonedDateTime.now(PrayerCalculator.SYRIA)
        val next = PrayerCalculator
            .timeline(now, SyrianCities.byId(s.cityId), s.method, s.madhhab)
            .nextNotifiable(now) ?: return

        val am = context.getSystemService(AlarmManager::class.java)
        val pi = pendingIntent(next.prayer)
        val at = next.time.toInstant().toEpochMilli()
        if (am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) // inexact fallback if exact alarms are denied
    }

    private fun pendingIntent(p: Prayer) = PendingIntent.getBroadcast(
        context, 0,
        Intent(context, PrayerAlarmReceiver::class.java).putExtra(EXTRA_PRAYER, p.name),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    companion object { const val EXTRA_PRAYER = "prayer" }
}
