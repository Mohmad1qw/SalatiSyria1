package sy.salati.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import sy.salati.ui.theme.SyColors
import kotlin.math.PI
import kotlin.math.sin

/** Slow, lightweight animated water: gradient sky + layered sine waves + faint Syrian star lattice. */
@Composable
fun WaterBackground(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val phase by rememberInfiniteTransition(label = "water").animateFloat(
        0f, (2 * PI).toFloat(),
        infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "phase"
    )
    val sky = if (dark) listOf(SyColors.Night, SyColors.DeepOlive, SyColors.DeepBlue)
              else listOf(SyColors.Ivory, SyColors.Stone, Color(0xFFBFE0E3))
    Box(modifier.fillMaxSize().background(Brush.verticalGradient(sky))) {
        Canvas(Modifier.fillMaxSize()) {
            drawStarLattice(if (dark) Color.White.copy(alpha = 0.045f) else SyColors.DeepOlive.copy(alpha = 0.06f))
            val a = if (dark) 0.16f else 0.18f
            drawWave(size.height * 0.72f, 26f, 1.3f, phase, SyColors.Water.copy(alpha = a))
            drawWave(size.height * 0.78f, 34f, 0.9f, -phase * 0.8f + 1.5f, SyColors.Emerald.copy(alpha = a + 0.06f))
            drawWave(size.height * 0.86f, 22f, 1.7f, phase * 0.6f + 3f, SyColors.DeepBlue.copy(alpha = a + 0.1f))
        }
        content()
    }
}

fun DrawScope.drawWave(baseY: Float, amp: Float, freq: Float, phase: Float, color: Color) {
    val path = Path().apply {
        moveTo(0f, size.height)
        var x = 0f
        while (x <= size.width + 12f) {
            lineTo(x, baseY + amp * sin(x / size.width * 2f * PI.toFloat() * freq + phase))
            x += 12f
        }
        lineTo(size.width, size.height); close()
    }
    drawPath(path, color)
}

/** Contemporary take on the Damascene eight-point star: two overlaid squares, hairline stroke. */
private fun DrawScope.drawStarLattice(color: Color) {
    val cell = 110.dp.toPx(); val r = cell * 0.30f
    var y = cell / 2
    while (y < size.height) {
        var x = cell / 2
        while (x < size.width) {
            val tl = Offset(x - r, y - r)
            drawRect(color, tl, Size(2 * r, 2 * r), style = Stroke(1.dp.toPx()))
            rotate(45f, Offset(x, y)) { drawRect(color, tl, Size(2 * r, 2 * r), style = Stroke(1.dp.toPx())) }
            x += cell
        }
        y += cell
    }
}
