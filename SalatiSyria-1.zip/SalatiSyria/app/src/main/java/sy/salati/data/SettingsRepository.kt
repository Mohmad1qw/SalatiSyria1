package sy.salati.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import sy.salati.domain.CalcMethod
import sy.salati.domain.Madhhab

private val Context.store by preferencesDataStore("salati_settings")

data class AppSettings(
    val cityId: String = "damascus",
    val method: CalcMethod = CalcMethod.EGYPT,
    val madhhab: Madhhab = Madhhab.SHAFII
)

class SettingsRepository(private val context: Context) {
    private val kCity = stringPreferencesKey("city")
    private val kMethod = stringPreferencesKey("method")
    private val kMadhhab = stringPreferencesKey("madhhab")

    val settings: Flow<AppSettings> = context.store.data.map { p ->
        AppSettings(
            cityId = p[kCity] ?: "damascus",
            method = p[kMethod]?.let { runCatching { CalcMethod.valueOf(it) }.getOrNull() } ?: CalcMethod.EGYPT,
            madhhab = p[kMadhhab]?.let { runCatching { Madhhab.valueOf(it) }.getOrNull() } ?: Madhhab.SHAFII
        )
    }

    suspend fun setCity(id: String) = context.store.edit { it[kCity] = id }
    suspend fun setMethod(m: CalcMethod) = context.store.edit { it[kMethod] = m.name }
    suspend fun setMadhhab(m: Madhhab) = context.store.edit { it[kMadhhab] = m.name }
}
