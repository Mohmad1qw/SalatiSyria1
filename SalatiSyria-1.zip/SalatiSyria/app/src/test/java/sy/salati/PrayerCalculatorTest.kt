package sy.salati

import org.junit.Assert.assertTrue
import org.junit.Test
import sy.salati.domain.*
import java.time.LocalDate

class PrayerCalculatorTest {
    @Test fun damascusOrderAndRange() {
        val t = PrayerCalculator.calculate(LocalDate.of(2026, 10, 10), SyrianCities.byId("damascus"), CalcMethod.EGYPT, Madhhab.SHAFII)
        assertTrue(t.zipWithNext().all { (a, b) -> a.time.isBefore(b.time) })      // strictly increasing
        val dhuhr = t.first { it.prayer == Prayer.DHUHR }.time
        assertTrue(dhuhr.hour == 12 && dhuhr.minute in 15..30)                      // ~12:23 expected
    }
}
